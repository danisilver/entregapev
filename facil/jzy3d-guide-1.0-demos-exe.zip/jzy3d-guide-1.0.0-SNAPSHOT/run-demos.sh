java -classpath "lib/*" org.jzy3d.demos.browser.DemoBrowser
cmd